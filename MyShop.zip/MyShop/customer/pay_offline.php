<center><!-- center Starts -->

<h1> Pagamento offline  </h1>

<p class="text-muted" >

Se tiver duvidas ou precisar de suporte, sinta-se livre e <a href="../contact.php" > fale conosco,</a> Temos um atendimento 24hrs disponivel a você!

</p>

</center><!-- center Ends -->

<hr>


<div class="table-responsive" ><!-- table-responsive Starts -->

<table class="table table-bordered table-hover table-striped" ><!-- table table-bordered table-hover table-striped Starts -->

<thead><!-- thead Starts -->

<tr>

<th> Detalher da conta bancaria </th>

<th> Detalhes do UBL Omni e Mobi Cash: </th>

<th> Detalher da Western Union : </th>

</tr>

</thead><!-- thead Ends -->

<tbody><!-- tbody Starts -->

<tr>

<td> Nome do banco: ubl Numero da conta:03333333 Branch Code:0342 Branch Name:DemoBranch	 </td>

<td> Pix:8437429672646264362462rfgd76463726493624293642964234 </td>

<td> Full Name:Demo Name, Mobile No:7000015000, Name:Demo, Country:BRA, N.I.C No:011234567
</td>


</tr>

</tbody><!-- tbody Ends -->


</table><!-- table table-bordered table-hover table-striped Ends -->

</div><!-- table-responsive Ends -->
